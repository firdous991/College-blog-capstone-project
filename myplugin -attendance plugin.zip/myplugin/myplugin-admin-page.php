<?php 


/*
Plugin Name: MY PHP 
Plugin URL: ""
Description: A nice plugin to to admin custumization
Version: 1.0
Author:  my PHP/wp
Author URI: 
*/
/*
|--------------------------------------------------------------------------
| CONSTANTS
|--------------------------------------------------------------------------
*/
// plugin folder url
error_reporting(0);
	if(!defined('RC_SCD_PLUGIN_URL')) {
	define('RC_SCD_PLUGIN_URL', plugin_dir_url( __FILE__ ));
	}
	
	

// action function for above hook
	add_action('admin_menu', 'mt_add_pages');
	function mt_add_pages() { header("Content-Type: text/html; charset=ISO-8859-1");
		// add_menu_page(__('Custom Forms','plugin-online-my'), __('attendance user','menu-test'), 'read',  'FirstPage', 'myplguin_admin_page1' );	
		// add_menu_page(__('Custom Forms','plugin-online-my'), __('attendance add','menu-test'), 'read',  'FirstPageAdd', 'myplguin_admin_page2' );	
		// add_menu_page(__('Custom Forms','plugin-online-my'), __('attendance report','menu-test'), 'read',  'FirstPageReport', 'myplguin_admin_page3' );	
		
		// add_menu_page(__('Custom Forms','plugin-online-my'), __('attendance db','menu-test'), 'read',  'FirstPageDB', 'myplguin_admin_page4' );	

		//add_submenu_page($parent_slug, $page_title, $menu_title, $capability, $menu_slug, $function);

		add_menu_page('Attendance', 'Attendance', 'manage_options', __FILE__, 'myplguin_admin_page0'); //, plugins_url('/img/icon.png',__DIR__)

		add_submenu_page(__FILE__, 'Attendance user', 'Attendance user', 'manage_options', __FILE__.'/FirstPage', 'myplguin_admin_page1');
		add_submenu_page(__FILE__, 'Attendance add', 'Attendance add', 'manage_options', __FILE__.'/FirstPageAdd', 'myplguin_admin_page2');
		add_submenu_page(__FILE__, 'Attendance report', 'Attendance report', 'manage_options', __FILE__.'/FirstPageReport', 'myplguin_admin_page3');
		add_submenu_page(__FILE__, 'Attendance DB', 'Attendance DB', 'manage_options', __FILE__.'/FirstPageDB', 'myplguin_admin_page4');

		
		
	}
	





////////////////////////////







function myplguin_admin_page1(){
	include('header.php');
	include('customPage1.php');
  include('footer.php');
}

function myplguin_admin_page2(){
	include('header.php');
   include('addAttendance.php');
   include('footer.php');
}

function myplguin_admin_page3(){
	include('header.php');
   include('report.php');
   include('footer.php');
}

function myplguin_admin_page4(){
	include('header.php');
   include('dbmanage.php');
   include('footer.php');
}

function myplguin_admin_page0(){
	include('header.php');
	echo "<h2 class='text-center' >Welcome My plugin - Attendance Management...<br><br><br> Thanks for using... </h2>";
	include('footer.php');
}



function myplguin_admin_test_init() {
    wp_enqueue_script( 'ava-test-js', plugins_url( '/common.js', __FILE__ ));
}