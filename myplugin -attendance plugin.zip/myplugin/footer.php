<script>


 function funAddUser(nam,id=0){
    $('#uuid').val(id);
    //$=Jquery;
    if(nam=="Edit"){
        $('#formUname').val($('#nameU'+id).html()); 
        $('#formUemail').val($('#emailU'+id).html());
         $('#formUtype').val($('#typeU'+id).html()); 
         $('#formUdob').val($('#dobU'+id).html());
    }else{
        $('#formUemail').val(''); $('#formUname').val(''); 
    }
   $('#addUserTitle').html(nam+' User');
    $('#modalAddUser').modal('show');

 }

 function funSelectUType(idd){
  
  var uurl = window.location.href;
  uurl = uurl+ '&utype='+idd;

  window.location.href =uurl;
 }

 function funSelectUser(idd){
     
 }

 function funSelectMonth(idd){
    var uurl = window.location.href;
    if(idd!=''){
        var mnth = idd.split('|');
        var mnthId= mnth[0];
        var mnthDay= mnth[1];
        uurl = uurl+ '&mDays='+mnthDay+'&mId='+mnthId;
    }else{
        uurl = uurl+ '&mDays=0&mId=0'; 
    }

    window.location.href =uurl;

 }
</script>
<div class="modal" tabindex="-1" role="dialog" id="modalAddUser">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="addUserTitle">Add User</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form method="post" action="" >
          <input type="hidden" name="uuid" id="uuid" value="0" >
        <div class="modal-body">
                <div class="row mb-10">
                    <div class="col-md-3 col-sm-3 col-xs-12 text-right">
                        <strong>Name</strong>
                    </div>
                    <div class="col-md-9 col-sm-9 col-xs-12 ">
                        <input type="text" name="name" id="formUname" class="form-control"  placeholder="Enter name" value="" maxlength="120" required />
                    </div>
                </div>

                <div class="row mb-10">
                    <div class="col-md-3 col-sm-3 col-xs-12 text-right">
                        <strong>Email</strong>
                    </div>
                    <div class="col-md-9 col-sm-9 col-xs-12 ">
                        <input type="email" name="email"  class="form-control"  id="formUemail" placeholder="Enter email" value="" maxlength="120" required />
                    </div>
                </div>

                <div class="row mb-10">
                    <div class="col-md-3 col-sm-3 col-xs-12 text-right">
                        <strong>DOB</strong>
                    </div>
                    <div class="col-md-9 col-sm-9 col-xs-12 ">
                        <input type="date" name="dob"  title="Date of Birth"  class="form-control"  id="formUdob" placeholder="Enter DOB" value="" maxlength="120" required />
                    </div>
                </div>


                <div class="row mb-10">
                    <div class="col-md-3 col-sm-3 col-xs-12 text-right">
                        <strong>Type</strong>
                    </div>
                    <div class="col-md-9 col-sm-9 col-xs-12 ">
                        <select class="form-control" name="type" id="uuType">
                            <?php foreach($uTypeArr as $u=>$v){
                                ?>
                                 <option value="<?=$u?>"><?=$v?></option>
                                <?php
                            } ?>
                               
                        </select>     
                    </div>
                </div>
        </div>
        <div class="modal-footer">
            <button type="submit" name="nameSubmit" value="user" class="btn btn-primary">Save changes</button>
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        </div>
      </form>
    </div>
  </div>
</div>
