<div>
    <div class="container">
        
          <?php ini_set('display_errors', '1'); ini_set('display_startup_errors', '1'); error_reporting(E_ALL);
$table ="wp_stu_users";
if(isset($_POST['nameSubmit']) && $_POST['nameSubmit'] && isset($_POST['name'])){
    $name= trim($_POST['name']);
    $email= trim($_POST['email']);
    $uuid= trim($_POST['uuid']);$type= trim($_POST['type']);
    $dob = $_POST['dob'];
    $arr=array(
        'name' => $name,
        'email' => $email ,
        'type' => $type ,
         'dob' => $dob 
    );
    if($uuid>0){
        $wpdb->update( $table, $arr,array('id'=>$uuid));
        $msg="Updated";
    }else{
        $wpdb->insert($table, $arr);
        $msg="Added";
    }
   
    ?>
    <script>
        alert('<?=$msg?>');
      //  window.location.reload();
    </script>
    <?php 

}


$sql="SELECT * FROM $table ORDER BY `id` DESC";   
$row = $wpdb->get_results( $sql, OBJECT );
 //print_r($row); // display data
?>
    <div class="col-md-12 col-sm-12 col-xs-12 ">
        <h2> All users <button onClick="funAddUser('Add')" type="button" class="btn btn-primary">Add User</button></h2> 
    </div>

   <div class="col-md-12 col-sm-12 col-xs-12 ">

            <table class="table">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Name</th>
                        <th scope="col">Email</th>
                        <th scope="col">Type</th>
                        <th scope="col" title="Date of Birth">DOB</th>
                        <th scope="col">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $c=0; foreach($row as  $r){  $c++;?>

                    <tr>
                        <th scope="row"><?=$c?></th>
                        <td id="nameU<?=$r->id?>"><?=$r->name?></td>
                        <td id="emailU<?=$r->id?>"><?=$r->email?></td>
                        <td id="typeU<?=$r->id?>"><?=$r->type?></td> 
                        <td id="dobU<?=$r->id?>"  title="Date of Birth"><?=$r->dob?></td>
                        <td>
                          <button onClick="funAddUser('Edit',<?=$r->id?>)" type="button" class="btn btn-primary">Edit</button>
                        </td>
                    </tr>
                   <?php  } ?>
                    
                    
                </tbody>
            </table>
        </div>



    </div>