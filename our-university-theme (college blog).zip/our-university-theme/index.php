<?php

  get_header();
  ?>
  <div class="page-banner">
      <div
        class="page-banner__bg-image"
        style="background-image: url('https://res.cloudinary.com/dul7ycim4/image/upload/v1607308267/bookbg_wuvpnz.jpg')"
      ></div>
      <div class="page-banner__content container container--narrow">
        <h1 class="page-banner__title">Welcome to our Blog</h1>
        <div class="page-banner__intro">
          <p>Keep up with our latest news</p>
        </div>
      </div>
    </div>
    <div class="container container--narrow page-section">
     <?php 
     while(have_posts()){
       the_post();
       ?>
      <div class="post-item">
        <h2 class="headline headline--medium headline--post-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
     </div>
      <div class='metabox'>
        <p>posted by <?php the_author_posts_link(); ?> on <?php the_time('n/j/y');?> in <?php echo get_the_category_list(", ");  ?></p>

      </div>

      <div class="generic-content">
        <?php the_excerpt();?>
     </div>
     <?php
     } echo paginate_links('String | 2');
     ?>
    
</div>
   
    <?php
  get_footer();



?>
