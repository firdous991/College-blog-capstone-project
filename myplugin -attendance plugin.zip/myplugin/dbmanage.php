<div>
    <div class="container">
        
          <?php ini_set('display_errors', '1'); ini_set('display_startup_errors', '1'); error_reporting(E_ALL);
$table ="wp_stu_users";
if(isset($_POST['nameSubmit']) && $_POST['nameSubmit']){
   
    $tblname = 'stu_pin';
    $wp_track_table = $table_prefix . "$tblname ";

    $table_name1 = $wpdb->prefix . 'stu_attendance';
    $table_name2 = $wpdb->prefix . 'stu_users';
    $table_name3 = $wpdb->prefix . 'stu_liveshoutbox';

	$sql = " CREATE TABLE `$table_name1` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `user_id` int(10) NOT NULL,
        `name` varchar(120) NOT NULL DEFAULT '',
        `month_id` int(3) NOT NULL,
        `a_date` date NOT NULL,
        `present` int(1) NOT NULL DEFAULT '0',
        `subject` text NULL DEFAULT NULL,
         PRIMARY KEY  (id)
        ) ENGINE=InnoDB DEFAULT CHARSET=latin1;

        CREATE TABLE `$table_name2` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `name` varchar(200) NOT NULL,
        `email` varchar(200) NOT NULL,
        `dob` date DEFAULT NULL,
        `type` varchar(20) NOT NULL DEFAULT 'student',
        `postdate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
         PRIMARY KEY  (id)
        ) ENGINE=InnoDB DEFAULT CHARSET=latin1;
    
    ";

        // CREATE TABLE IF NOT EXISTS $table_name (
        //     id mediumint(9) NOT NULL AUTO_INCREMENT,
        //     time datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
        //     name tinytext NOT NULL,
        //     text text NOT NULL,
        //     url varchar(100) DEFAULT '' NOT NULL,
        //     PRIMARY KEY  (id)
        // );

	require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
	dbDelta( $sql );

    $msg="Updated!!";
    ?>
    <script>
     //   alert('<?=$msg?>');
      //  window.location.reload();
    </script>
    <?php 

}


 //print_r($row); // display data
?>
    <div class="col-md-12 col-sm-12 col-xs-12 ">
        <h2> Manage Database 
        <form method="post" action="" style="float:right;">
            <input  type="submit" name="nameSubmit" class="btn btn-primary" value="Update DB" />
        </form>
            </h2> 
    </div>


      

  </div>

</div>