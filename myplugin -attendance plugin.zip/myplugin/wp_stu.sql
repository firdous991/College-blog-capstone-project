-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 27, 2020 at 11:50 AM
-- Server version: 10.1.40-MariaDB
-- PHP Version: 7.3.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `wp_stu`
--

-- --------------------------------------------------------

--
-- Table structure for table `wp_stu_attendance`
--

CREATE TABLE `wp_stu_attendance` (
  `id` int(11) NOT NULL,
  `user_id` int(10) NOT NULL,
  `name` varchar(120) NOT NULL DEFAULT '',
  `month_id` int(3) NOT NULL,
  `a_date` date NOT NULL,
  `present` int(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `wp_stu_attendance`
--

INSERT INTO `wp_stu_attendance` (`id`, `user_id`, `name`, `month_id`, `a_date`, `present`) VALUES
(1, 1, 'v01', 11, '2020-11-27', 1),
(2, 1, 'v01', 11, '2020-11-19', 1),
(3, 2, 'jj', 10, '2020-10-27', 1),
(4, 1, 'v01', 10, '2020-10-27', 1);

-- --------------------------------------------------------

--
-- Table structure for table `wp_stu_users`
--

CREATE TABLE `wp_stu_users` (
  `id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `dob` date DEFAULT NULL,
  `type` varchar(20) NOT NULL DEFAULT 'student',
  `postdate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `wp_stu_users`
--

INSERT INTO `wp_stu_users` (`id`, `name`, `email`, `dob`, `type`, `postdate`) VALUES
(1, 'v01', 'v1@v.com', '2020-11-04', 'student', '2020-11-27 10:05:41'),
(2, 'jj', 'jb@jb.com', '2016-10-30', 'student', '2020-11-27 10:49:35');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `wp_stu_attendance`
--
ALTER TABLE `wp_stu_attendance`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wp_stu_users`
--
ALTER TABLE `wp_stu_users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `wp_stu_attendance`
--
ALTER TABLE `wp_stu_attendance`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `wp_stu_users`
--
ALTER TABLE `wp_stu_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
