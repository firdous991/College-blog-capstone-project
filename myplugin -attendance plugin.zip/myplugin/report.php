<?php 
$dateSel=date('Y-m-d');
$table = $wpdb->prefix."stu_users";
$utype ="employee";
$whr= "where type='$utype' ";
if(isset($_GET['utype']) && trim($_GET['utype'])!=''){
    $utype= trim($_GET['utype']);
    $whr= "where type='$utype' ";
}
$sql="SELECT id FROM $table $whr ORDER BY `id` DESC";   
$rowU = $wpdb->get_results( $sql, OBJECT );
$AllUid= array();
foreach ($rowU as  $value) {
    $AllUid[]=$value->id;
}
$AllUidStr = implode(',',$AllUid);

$tbl = $wpdb->prefix."stu_attendance";

if(isset($_GET['monthDate']) && trim($_GET['monthDate'])!=''){
    $dateSel= trim($_GET['monthDate']);
}

$rowR = array();
if(trim($AllUidStr)!=''){
    $whrR= "where a_date='$dateSel' and user_id IN($AllUidStr) ";

    $sql="SELECT $tbl.*,$table.dob,$table.email FROM $tbl JOIN $table ON $table.id=$tbl.user_id $whrR ORDER BY `id` DESC";   
    $rowR = $wpdb->get_results( $sql, OBJECT );
}

?>
    <div class="row mb-10">
        <div class="col-md-12 col-sm-12 col-xs-12 ">
            <h2> Attendance Report 
            </h2> 
        </div>
    </div>

<form action="" method="GET">
    <input type="hidden" name="page" value="<?=$_GET['page']?>" /> 
    <div class="row mb-10">
                    <div class="col-md-3 col-sm-3 col-xs-12 text-right">
                        <strong>User Type</strong>
                    </div>
                    <div class="col-md-9 col-sm-9 col-xs-12 ">
                        <select class="form-control" name="utype" id="userTypeSelectAddAtt" >
                            <?php foreach($uTypeArr as $u=>$v){
                                ?>
                                 <option value="<?=$u?>" <?=isset($utype) && $utype==$u?'selected':'' ?>  ><?=$v?></option>
                                <?php
                            } ?>
                               
                        </select>                   
                    </div>
    </div>
    <div class="row mb-10">
                    <div class="col-md-3 col-sm-3 col-xs-12 text-right">
                        <strong>Date</strong>
                    </div>
                    <div class="col-md-9 col-sm-9 col-xs-12 ">
                        <input style="    width: 250px;" type="date" required name="monthDate"  value="<?=$dateSel?>" class="form-control" />
                    </div>
    </div>
    <div class="row mb-10">
                    <div class="col-md-3 col-sm-3 col-xs-12 text-right">
                        <strong></strong>
                    </div>
                    <div class="col-md-9 col-sm-9 col-xs-12 ">
                        <input  type="submit" required name="checkReport"  value="Check" class="btn-primary" />
                    </div>
    </div>
</form> 
   
   <div class="col-md-12 col-sm-12 col-xs-12 ">

   

            <table class="table">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Name</th> <th scope="col">Email</th><th scope="col">DOB</th>
                        <th scope="col">Marked Attendance</th> 
                        <th scope="col">Subject</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $c=0;
                    if($rowR && count($rowR)){

                    
                    foreach($rowR as  $r){  $c++;?>

                    <tr>
                        <th scope="row"><?=$c?></th>
                        <td id="nameU<?=$r->id?>"><?=$r->name?></td>
                        <td id="nameUE<?=$r->id?>"><?=$r->email?></td>
                        <td id="nameUD<?=$r->id?>"><?=$r->dob?></td>
                       
                        <td id="typeU<?=$r->id?>" class="<?=$r->present?"bg-success":"bg-danger" ?>"><?=$r->present?"Present":"Absent" ?></td> 
                         <td id="subjectUD<?=$r->id?>"><?=$r->subject!=null? $r->subject : '' ?></td>
                    </tr>
                   <?php  } 
                   }else{
                       ?>
                       <center><h2>No results found!!</h2></center>
                       <?php
                   }
                   
                   ?>
                    
                    
                </tbody>
            </table>
        </div>



    </div>