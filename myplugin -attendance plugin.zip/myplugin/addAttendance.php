<div>
    <div class="container">
      
          <?php ini_set('display_errors', '1'); ini_set('display_startup_errors', '1'); error_reporting(E_ALL);

if(isset($_POST['nameSubmit']) && $_POST['nameSubmit'] && isset($_POST['monthDate']) && trim($_POST['monthDate'])!=''
  ){
    $monthDate = $_POST['monthDate'];
    $mnthArr = explode('-',$_POST['monthDate']);
    $day=$mnthArr[2];
    $month=$mnthArr[1];
    $year=$mnthArr[0];

   
   $userCheckID= $_POST['userCheckID'];

   $userCheck= $_POST['userCheck'];
   if(!is_array($userCheck)){
    $userCheck =array();
   }

  // echo "<pre>";
    foreach($userCheckID as $eachU){
        $eachUAr = explode('|',$eachU); 
        $uu =$eachUAr[0];
        $uuName =$eachUAr[1];
        $setA=0;
        if(in_array($uu,  $userCheck)){
            $setA=1;
        }
         $tbl = $wpdb->prefix."stu_attendance";
        $sql="SELECT * FROM  $tbl where user_id='$uu' and a_date='$monthDate'";   
        $roWs = $wpdb->get_row( $sql, ARRAY_A );
        //print_r($roWs ); 
      
        if( isset($roWs['id']) ){
            $upArr = array('present'=>$setA);
            $where=array( 'user_id' => $uu, 'a_date' => $monthDate);
            if(isset($_POST['subject']) && trim($_POST['subject'])!='' ){
                $upArr['subject'] = $_POST['subject'];
            }
           
            $wpdb->update( $tbl, $upArr , $where);
        }else{
            $insArr= array(
                'user_id' => $uu,
                'name' =>  $uuName,
                'a_date' => $monthDate,
                'month_id' => $month,
                'present'=>$setA
            );
            if(isset($_POST['subject']) && trim($_POST['subject'])!='' ){
                $insArr['subject'] = $_POST['subject'];
            }
            $wpdb->insert($tbl, $insArr);
        }
    
    }

   
 
    $msg="Added";
    ?>
    <script>
        alert('<?=$msg?>');
        
    </script>
    <?php 

}

$table = $wpdb->prefix."stu_users";


$utype ="employee";
$whr= "where type='$utype' ";
if(isset($_GET['utype']) && trim($_GET['utype'])!=''){
    $utype= trim($_GET['utype']);
    $whr= "where type='$utype' ";
}
$mId=0;
if(isset($_GET['mId']) && trim($_GET['mId'])>0){
    $mId= trim($_GET['mId']);
  
}

$mDays=0;
if(isset($_GET['mDays']) && trim($_GET['mDays'])>0){
    $mDays= trim($_GET['mDays']);
  
}

$sql="SELECT * FROM $table $whr ORDER BY `id` DESC";   
$rowU = $wpdb->get_results( $sql, OBJECT );
 //echo "<pre>";print_r($rowU); die; // display data
$totDays=31;
?>
    <div class="col-md-12 col-sm-12 col-xs-12 ">
        <h2> Add  Attendance </h2> 
    </div>

    <form method="post" action="" >
          <input type="hidden" name="uuid" id="uuid" value="0" >
        <div class="add attend">
                <div class="row mb-10">
                    <div class="col-md-3 col-sm-3 col-xs-12 text-right">
                        <strong>User Type</strong>
                    </div>
                    <div class="col-md-9 col-sm-9 col-xs-12 ">
                        <select class="form-control" name="type" id="userTypeSelectAddAtt" onChange="funSelectUType(this.value)">
                            <?php foreach($uTypeArr as $u=>$v){
                                ?>
                                 <option value="<?=$u?>" <?=isset($utype) && $utype==$u?'selected':'' ?>  ><?=$v?></option>
                                <?php
                            } ?>
                               
                        </select>                   
                    </div>
                </div>

             
                <div class="row mb-10">
                    <div class="col-md-3 col-sm-3 col-xs-12 text-right">
                        <strong>Date</strong>
                    </div>
                    <div class="col-md-9 col-sm-9 col-xs-12 ">
                       
                        <input style="    width: 250px;" type="date" required name="monthDate"  value="<?=date('Y-m-d')?>" class="form-control" />
                    </div>
                </div>
                <div class="row mb-10">
                    <div class="col-md-3 col-sm-3 col-xs-12 text-right">
                        <strong>Subject</strong>
                    </div>
                    <div class="col-md-9 col-sm-9 col-xs-12 ">
                       
                        <input style="    width: 250px;" type="text"  name="subject"  value="" class="form-control" />
                    </div>
                </div>



        </div>

        <?php //if( isset($mId) && $mId>0 &&   isset($mDays) && $mDays>0){ ?>
            <!-- <div class="row mb-10">
                    <div class="col-md-3 col-sm-3 col-xs-12 text-right">
                        <strong>Day</strong>
                    </div>
                    <div class="col-md-9 col-sm-9 col-xs-12 ">
                        <select required class="form-control" name="month" id="idSelMonthDay">
                        <option value="">Select Day</option>
                        <?php for($i=1;$i<=$mDays; $i++){
                                    ?>
                                    <option  value="<?=$i?>">Day <?=$i?></option>
                                    <?php
                                } ?>
                        </select>
                    </div>
                </div> -->

                <div class="row mb-10">
                    <div class="col-md-12 col-sm-12 col-xs-12 text-left">
                    
                        <table class="table">
                            <thead>
                                <tr>
                                <th>S.No</th>
                                <th>User Name</th>
                                <th> user email</th>
                                <th> mark</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $j=0; foreach($rowU as  $v){ $j++; ?>
                                <tr>
                                    <td><?=$j?></td>
                                    <td><?=$v->name?></td>
                                    <td><?=$v->email?></td>
                                    <td>  
                                    <input type="hidden" class="form-control" name="userCheckID[]" value="<?=$v->id?>|<?=$v->name?>" />    
                                    <div class="checkbox">
                                        <label><input type="checkbox"  name="userCheck[]" value="<?=$v->id?>">Click to mark Attendance</label>
                                    </div>
                                    </td>
                                </tr>
                                <?php
                                } ?>
                            </tbody>
                        </table>
                    </div>
                   
                </div>

                <div class="row mb-10">
                    <div class="col-md-12 col-sm-12 col-xs-12 text-left">
                    <button type="submit" name="nameSubmit" value="user" class="btn btn-primary">Save changes</button>
                         <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    </div>
                   
                </div>
           
      <?php //} ?>
      </form>
      


    </div>