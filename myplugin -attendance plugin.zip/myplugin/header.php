<?php 
global $wpdb, $table_prefix;
$uTypeArr =array('employee'=>'Employee','student'=>'Student');
?>

<link rel="stylesheet" href="<?=plugins_url( '/css/bootstrap.min.css', __FILE__ )?>" />

<script src="<?=plugins_url( '/js/jquery-3.5.1.min.js', __FILE__ )?>"> </script>
<script src="<?=plugins_url( '/js/bootstrap.min.js', __FILE__ )?>"> </script>
<style>
.mb-10{
    margin-bottom: 20px;
}



</style>