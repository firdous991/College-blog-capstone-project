
		<footer class="footer-distributed">

<div class="footer-right">

  <a href="#"><i class="fa fa-facebook"></i></a>
  <a href="#"><i class="fa fa-twitter"></i></a>
  <a href="#"><i class="fa fa-linkedin"></i></a>
  <a href="#"><i class="fa fa-github"></i></a>

</div>

<div class="footer-left">

  <p class="footer-links">
    <a class="link-1" href="<?php echo site_url('/home')?>">Home</a>

    <a href="<?php echo site_url('/about-us')?>">About</a>


    <a href="<?php echo site_url('/blog')?>">Blogs</a>
      <a href="<?php echo site_url('/contact-us')?>">Contact us</a>

    <a href="<?php echo site_url('/privacy-policy')?>">Privacy Policy</a>

  </p>

  <p>College Blog &copy; 2020</p>
</div>

</footer>
<?php wp_footer();?>
</body>
</html>